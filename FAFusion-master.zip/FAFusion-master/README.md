FAFusion: Learning for Infrared and Visible Image Fusion via Frequency Awareness
Guobao Xiao, Zhimin Tang, Hanlin Guo, Jun Yu and Heng Tao Shen
IEEE Transactions on Instrumentation and Measurement (TIM), 2024, 73, 1-11
# FAFuison implementation
pytorch implementation of FAFusion
